/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaces;

/**
 *
 * @author ericd
 */
public interface OperacoesEspecializadas {
    
    public float raiz(float num1);
    public float seno(float num1);
    public float coseno(float num1);
    
}
